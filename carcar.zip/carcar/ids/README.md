# iDS : The Dataset Library for [iSeg](https://github.com/edwardyehuang/iSeg)
